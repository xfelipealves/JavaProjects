package Decorator;

import Models.*;

public abstract class Personalizacao extends Sanduiche {
    protected Produto produto;
}
