package Models;

public class MacOvoFrito extends Acompanhamento{
    private String nome = "MacOvoFrito";
    public MacOvoFrito() {
    }
    @Override
    public String toString() {
        return "Acompanhamento = " + nome;
    }
}
