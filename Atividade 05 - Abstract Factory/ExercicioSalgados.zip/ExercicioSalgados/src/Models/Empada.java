package Models;

public class Empada extends Salgado{
    public Empada(String massa, String molho, String recheio) {
        this.massa = massa;
        this.molho = molho;
        this.recheio = recheio;
    }
}
