package Models;

public abstract class Sanduiche implements Produto {
}
