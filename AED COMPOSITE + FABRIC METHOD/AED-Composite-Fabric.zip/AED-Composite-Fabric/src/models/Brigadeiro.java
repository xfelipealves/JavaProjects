package models;

public class Brigadeiro extends Doce{
    private String tipo = "Brigadeiro";
    public Brigadeiro() {
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
