package Model;

public class Guarana extends Refrigerante{
    public Guarana(String nome) {
        super(nome);
    }
}
