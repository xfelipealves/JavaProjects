package ex4;

public interface Controle {
    public void power();
    public void setVolume(int volume);
}
