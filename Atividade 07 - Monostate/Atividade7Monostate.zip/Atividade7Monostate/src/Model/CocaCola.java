package Model;

public class CocaCola extends Refrigerante{
    public CocaCola(String nome) {
        super(nome);
    }
}
