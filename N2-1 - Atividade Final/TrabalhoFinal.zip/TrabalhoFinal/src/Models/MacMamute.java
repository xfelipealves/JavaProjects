package Models;

public class MacMamute extends Sanduiche{
    private String nome = "MacMamute";
    public MacMamute() {
    }
    @Override
    public String toString() {
        return "Sanduíche = " + nome;
    }
}
