package models;

public interface Cerveja {
    public abstract void produzir();
}
