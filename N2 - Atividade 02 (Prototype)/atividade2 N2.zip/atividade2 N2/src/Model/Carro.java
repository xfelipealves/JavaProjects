package Model;

public class Carro extends Veiculo {

    @Override
    public String toString() {
        return "Carro{" +
                "pneus=" + pneus +
                '}';
    }
}
