package Models;

public interface Produto {
}
