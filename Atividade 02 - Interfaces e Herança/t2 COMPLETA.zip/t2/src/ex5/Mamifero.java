package ex5;

public interface Mamifero {

    public void caminhar();
    public void alimentar();
}
