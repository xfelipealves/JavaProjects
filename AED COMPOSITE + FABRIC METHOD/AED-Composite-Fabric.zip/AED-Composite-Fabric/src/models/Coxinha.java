package models;

public class Coxinha extends Salgado{
    private String tipo = "Coxinha";
    public Coxinha() {
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
