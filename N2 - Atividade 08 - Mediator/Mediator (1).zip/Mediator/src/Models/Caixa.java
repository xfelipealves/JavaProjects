package Models;

public abstract interface Caixa {
    public abstract void listaFila();
    public abstract void redirecionar(int senha);
    public abstract void atender();
}
