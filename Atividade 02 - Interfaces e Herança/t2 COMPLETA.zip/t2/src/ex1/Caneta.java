package ex1;

public interface Caneta {
    public void escrever(String texto);

    public String getCor();
}
