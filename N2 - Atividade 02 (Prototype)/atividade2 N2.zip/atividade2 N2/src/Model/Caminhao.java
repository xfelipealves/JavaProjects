package Model;

public class Caminhao extends Veiculo {

    @Override
    public String toString() {
        return "Caminhao{" +
                "pneus=" + pneus +
                '}';
    }
}