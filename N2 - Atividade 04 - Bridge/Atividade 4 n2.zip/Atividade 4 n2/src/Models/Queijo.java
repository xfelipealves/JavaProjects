package Models;

public class Queijo extends Recheio{
    public Queijo() {
    }

    @Override
    public String toString() {
        return "Recheio de queijo.";
    }
}
