package Models;

public class Carne extends Recheio{
    public Carne() {
    }

    @Override
    public String toString() {
        return "Recheio de carne.";
    }
}
