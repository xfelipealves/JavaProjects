package Models;

public class Coxinha extends Salgado{
    public Coxinha(String massa, String molho, String recheio) {
        this.massa = massa;
        this.molho = molho;
        this.recheio = recheio;
    }
}
