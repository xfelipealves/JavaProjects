package devices;

public class Voltagem220 {
    private String energia220="220v";

    public Voltagem220() {
    }

    public String getEnergia220() {
        return energia220;
    }
}
