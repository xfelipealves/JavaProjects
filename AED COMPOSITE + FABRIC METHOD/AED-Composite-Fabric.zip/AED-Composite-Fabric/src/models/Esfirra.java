package models;

public class Esfirra extends Salgado{
    private String tipo = "Esfirra";
    public Esfirra() {
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
