package Models;

public class MacRaptor extends Sanduiche{
    private String nome = "MacRaptor";
    public MacRaptor() {
    }
    @Override
    public String toString() {
        return "Sanduíche = " + nome;
    }
}
