package devices;

public class Voltagem110 {
    private String energia110="110v";

    public Voltagem110() {
    }

    public String getEnergia110() {
        return energia110;
    }
}
