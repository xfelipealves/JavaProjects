package ex1;

public class Assistente extends Funcionario {
    private int matricula;

    protected int getMatricula() {
        return matricula;
    }

    protected void setMatricula(int matricula) {
        this.matricula = matricula;
    }
}
