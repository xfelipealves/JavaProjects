package models;

public class Sorvete extends Doce{
    private String tipo = "Sorvete";
    public Sorvete() {
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
