package Models;

public class Frango extends Recheio{
    public Frango() {
    }

    @Override
    public String toString() {
        return "Recheio de frango.";
    }
}
