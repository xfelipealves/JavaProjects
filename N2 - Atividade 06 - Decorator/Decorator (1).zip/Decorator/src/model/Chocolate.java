package model;

public abstract class Chocolate {
    protected String descricao = "Chocolate";
    public abstract String getDescricao();
}
