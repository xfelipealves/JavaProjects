package Interface;

public interface Produto {
    public void imprimir();
    public double getValor();
}
