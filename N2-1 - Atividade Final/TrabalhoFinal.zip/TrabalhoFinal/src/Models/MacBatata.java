package Models;

public class MacBatata extends Acompanhamento{
    private String nome = "MacBatata";
    public MacBatata() {
    }
    @Override
    public String toString() {
        return "Acompanhamento = " + nome;
    }
}
