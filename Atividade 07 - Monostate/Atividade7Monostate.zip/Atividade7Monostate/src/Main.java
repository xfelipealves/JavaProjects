import Factory.*;
public class Main {
    public static void main(String[] args) {
        System.out.println(FactoryRefrigerante.venda(2));
        System.out.println(FactoryRefrigerante.venda(6));
        System.out.println(FactoryRefrigerante.venda(5));
    }
}