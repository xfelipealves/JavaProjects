package Decorator;

import model.*;

public abstract class Tipo extends Chocolate {
    protected Chocolate chocolate;
    public abstract String getDescricao();

}
