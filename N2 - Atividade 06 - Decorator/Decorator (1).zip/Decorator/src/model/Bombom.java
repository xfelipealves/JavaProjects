package model;

public class Bombom extends Chocolate{
    @Override
    public String getDescricao() {
        return descricao + ", Bombom";
    }
}
