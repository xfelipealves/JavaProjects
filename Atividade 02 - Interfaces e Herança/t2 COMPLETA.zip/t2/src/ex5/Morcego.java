package ex5;

public class Morcego implements Mamifero, Voador{
    @Override
    public void caminhar() {

    }

    @Override
    public void alimentar() {

    }

    @Override
    public void voar() {

    }

    @Override
    public void comunicar() {

    }
}
