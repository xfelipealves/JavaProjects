package ex2;

public interface Entrega {
    public String getIdentificador();
    public String getCidadeOrigem();
    public String getCidadeDestino();
}
