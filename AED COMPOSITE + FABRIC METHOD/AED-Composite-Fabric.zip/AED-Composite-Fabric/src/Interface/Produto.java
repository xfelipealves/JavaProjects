package Interface;

public interface Produto {
    public void listar();
    public String getTipo();
}
