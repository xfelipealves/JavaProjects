package models;

public class Stout implements Cerveja{
    @Override
    public void produzir() {
        System.out.println("Cerveja de Stout");
    }
}
