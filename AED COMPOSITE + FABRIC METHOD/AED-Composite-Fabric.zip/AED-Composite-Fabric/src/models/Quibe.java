package models;

public class Quibe extends Salgado{
    private String tipo = "Quibe";
    public Quibe() {
    }
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
