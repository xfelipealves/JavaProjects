package Models;

public abstract class Salgado {
    protected Recheio recheio;

    public Salgado(Recheio recheio) {
        this.recheio = recheio;
    }
}
