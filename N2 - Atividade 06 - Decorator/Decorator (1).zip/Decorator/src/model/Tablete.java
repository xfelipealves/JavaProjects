package model;

public class Tablete extends Chocolate{
    @Override
    public String getDescricao() {
        return descricao + ", Tablete";
    }
}
