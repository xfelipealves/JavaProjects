package Models;

public class MacRex extends Sanduiche{
    private String nome = "MacRex";
    public MacRex() {
    }
    @Override
    public String toString() {
        return "Sanduíche = " + nome;
    }
}
