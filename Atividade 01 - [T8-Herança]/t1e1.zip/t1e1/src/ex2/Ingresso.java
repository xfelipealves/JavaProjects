package ex2;

public class Ingresso {
    private double valor;

    public Ingresso(double valor) {
        this.valor = valor;
    }

    public String imprimeValor() {
        return Double.toString(valor);
    }


}
