package models;

public class Bolo extends Doce{
    private String tipo = "Bolo";
    public Bolo() {
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
