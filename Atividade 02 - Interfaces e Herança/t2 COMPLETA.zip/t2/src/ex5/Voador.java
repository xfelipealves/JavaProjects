package ex5;

public interface Voador {
    public void voar();
    public void comunicar();
}
