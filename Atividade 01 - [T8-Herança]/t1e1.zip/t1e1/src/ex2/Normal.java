package ex2;

public class Normal extends Ingresso{

    public Normal(double valor) {
        super(valor);
    }

    public String imprime() {
        return "Ingresso Normal";
    }
}
