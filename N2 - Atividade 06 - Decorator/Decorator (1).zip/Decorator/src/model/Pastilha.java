package model;

public class Pastilha extends Chocolate{
    @Override
    public String getDescricao() {
        return descricao + ", Pastilha";
    }
}
