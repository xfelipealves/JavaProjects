package Models;

public abstract class Acompanhamento implements Produto {
}
