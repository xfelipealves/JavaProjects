package Models;

public abstract class Recheio {
    public Recheio() {
    }
}
