package Models;

public abstract class Refrigerante implements Produto {
}
